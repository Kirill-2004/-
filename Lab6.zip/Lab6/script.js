class Calculator {
    constructor() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
        this.updateDisplay();
    }

    clear() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
    }

    clearEntry() {
        this.currentOperand = '0';
    }

    delete() {
        if (this.currentOperand === '0') return;
        this.currentOperand = this.currentOperand.slice(0, -1);
        if (this.currentOperand === '') this.currentOperand = '0';
    }

    appendNumber(number) {
        if (number === '.' && this.currentOperand.includes('.')) return;
        if (this.currentOperand === '0' && number !== '.') {
            this.currentOperand = number;
        } else {
            this.currentOperand += number;
        }
    }

    chooseOperation(operation) {
        if (this.currentOperand === '') return;
        if (this.previousOperand !== '') {
            this.compute();
        }
        this.operation = operation;
        this.previousOperand = this.currentOperand;
        this.currentOperand = '';
    }

    compute() {
        let computation;
        const prev = parseFloat(this.previousOperand);
        const current = parseFloat(this.currentOperand);
        if (isNaN(prev) || isNaN(current)) return;

        switch (this.operation) {
            case '+':
                computation = prev + current;
                break;
            case '-':
                computation = prev - current;
                break;
            case '×':
                computation = prev * current;
                break;
            case '÷':
                if (current === 0) {
                    alert('Деление на ноль невозможно');
                    return;
                }
                computation = prev / current;
                break;
            default:
                return;
        }

        this.currentOperand = computation.toString();
        this.operation = undefined;
        this.previousOperand = '';
    }

    specialOperation(operation) {
        let number = parseFloat(this.currentOperand);
        switch (operation) {
            case 'sqrt':
                if (number < 0) {
                    alert('Невозможно извлечь корень из отрицательного числа');
                    return;
                }
                this.currentOperand = Math.sqrt(number).toString();
                break;
            case 'square':
                this.currentOperand = (number * number).toString();
                break;
            case 'inverse':
                if (number === 0) {
                    alert('Деление на ноль невозможно');
                    return;
                }
                this.currentOperand = (1 / number).toString();
                break;
            case 'negate':
                this.currentOperand = (-number).toString();
                break;
            case 'percent':
                this.currentOperand = (number / 100).toString();
                break;
        }
    }

    updateDisplay() {
        document.querySelector('.current-operand').textContent = this.currentOperand;
        if (this.operation != null) {
            document.querySelector('.previous-operand').textContent = 
                `${this.previousOperand} ${this.operation}`;
        } else {
            document.querySelector('.previous-operand').textContent = '';
        }
    }
}

const calculator = new Calculator();

// Обработчики событий для цифр
document.querySelectorAll('.number').forEach(button => {
    button.addEventListener('click', () => {
        calculator.appendNumber(button.textContent);
        calculator.updateDisplay();
    });
});

// Обработчики событий для операций
document.querySelectorAll('.operation').forEach(button => {
    button.addEventListener('click', () => {
        const action = button.dataset.action;
        switch (action) {
            case 'add':
            case 'subtract':
            case 'multiply':
            case 'divide':
                calculator.chooseOperation(button.textContent);
                break;
            case 'c':
                calculator.clear();
                break;
            case 'ce':
                calculator.clearEntry();
                break;
            case 'backspace':
                calculator.delete();
                break;
            case 'sqrt':
            case 'square':
            case 'inverse':
            case 'negate':
            case 'percent':
                calculator.specialOperation(action);
                break;
        }
        calculator.updateDisplay();
    });
});

// Обработчик для равно
document.querySelector('.equals').addEventListener('click', () => {
    calculator.compute();
    calculator.updateDisplay();
});

// Обработка клавиатуры
document.addEventListener('keydown', event => {
    if (/[0-9]/.test(event.key)) {
        calculator.appendNumber(event.key);
    } else if (event.key === '.') {
        calculator.appendNumber('.');
    } else if (event.key === 'Enter') {
        calculator.compute();
    } else if (event.key === 'Backspace') {
        calculator.delete();
    } else if (event.key === 'Escape') {
        calculator.clear();
    } else if (['+', '-', '*', '/'].includes(event.key)) {
        const operations = {
            '+': '+',
            '-': '-',
            '*': '×',
            '/': '÷'
        };
        calculator.chooseOperation(operations[event.key]);
    }
    calculator.updateDisplay();
});

// Обработка изменения значения ползунка цены
document.getElementById('price').addEventListener('input', function(e) {
    const value = parseInt(e.target.value);
    document.getElementById('priceOutput').textContent = 
        new Intl.NumberFormat('ru-RU').format(value) + ' ₽';
});

// Обработка отправки формы
function handleSubmit(event) {
    event.preventDefault();
    
    // Проверяем валидность формы
    if (!event.target.checkValidity()) {
        alert('Пожалуйста, заполните все обязательные поля');
        return;
    }

    // Собираем данные формы
    const formData = new FormData(event.target);
    const data = {};
    
    // Получаем выбранные опции
    const options = [];
    document.querySelectorAll('input[name="options"]:checked').forEach(checkbox => {
        options.push(checkbox.labels[0].textContent);
    });

    // Собираем все данные в объект
    formData.forEach((value, key) => {
        if (key !== 'options') {
            data[key] = value;
        }
    });
    data.options = options;

    // Форматируем данные для вывода
    const resultHTML = `
        <h2>✓ Автомобиль успешно зарегистрирован</h2>
        <p><strong>Марка:</strong> ${data.brand}</p>
        <p><strong>Модель:</strong> ${data.model}</p>
        <p><strong>Год выпуска:</strong> ${data.year}</p>
        <p><strong>Цена:</strong> ${document.getElementById('priceOutput').textContent}</p>
        <p>
            <strong>Цвет:</strong> 
            <span class="color-preview" style="background-color: ${data.color};"></span>
        </p>
        <p><strong>Тип двигателя:</strong> ${document.getElementById('engine').options[document.getElementById('engine').selectedIndex].text}</p>
        <p><strong>Состояние:</strong> ${data.condition === 'new' ? 'Новый' : 'Б/у'}</p>
        <p><strong>Комплектация:</strong> ${options.length ? options.join(', ') : 'Базовая'}</p>
        <p><strong>Описание:</strong> ${data.description || 'Не указано'}</p>
    `;

    // Показываем результат
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = resultHTML;
    resultDiv.classList.remove('hidden');
    resultDiv.classList.add('visible');

    // Плавно прокручиваем к результату
    resultDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    // Очищаем форму
    event.target.reset();
    document.getElementById('priceOutput').textContent = '1 000 000 ₽';

    // Сбрасываем цвет к значению по умолчанию
    document.getElementById('color').value = '#000000';
}

// Добавляем placeholder для мобильной версии
function updatePlaceholders() {
    if (window.innerWidth <= 768) {
        const inputs = document.querySelectorAll('input[type="text"], input[type="number"], select, textarea');
        inputs.forEach(input => {
            const label = document.querySelector(`label[for="${input.id}"]`);
            if (label) {
                input.placeholder = label.textContent;
            }
        });
    }
}

// Обновляем placeholder при загрузке и изменении размера окна
window.addEventListener('load', updatePlaceholders);
window.addEventListener('resize', updatePlaceholders); 