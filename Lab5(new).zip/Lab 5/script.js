function calculateMushrooms() {
    // Получаем значение из поля ввода
    const number = parseInt(document.getElementById('numberInput').value);
    const resultElement = document.getElementById('result');
    
    // Проверяем корректность ввода
    if (isNaN(number) || number < 0) {
        resultElement.textContent = 'Пожалуйста, введите положительное число';
        resultElement.style.color = '#ff4444';
        return;
    }

    // Получаем последнюю цифру и последние две цифры
    const lastDigit = number % 10;
    const lastTwoDigits = number % 100;

    // Определяем правильное окончание
    let ending;
    if (lastTwoDigits >= 11 && lastTwoDigits <= 19) {
        ending = 'грибов';
    } else if (lastDigit === 1) {
        ending = 'гриб';
    } else if (lastDigit >= 2 && lastDigit <= 4) {
        ending = 'гриба';
    } else {
        ending = 'грибов';
    }

    // Выводим результат
    resultElement.textContent = `${number} ${ending}`;
    resultElement.style.color = '#333';
}

// Добавляем обработчик события для клавиши Enter
document.getElementById('numberInput').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        calculateMushrooms();
    }
});

// Очистка поля ввода при фокусе
document.getElementById('numberInput').addEventListener('focus', function() {
    this.value = '';
    document.getElementById('result').textContent = '';
}); 