function processArray() {
    // Получаем введенные данные и преобразуем их в массив чисел
    const input = document.getElementById('arrayInput').value;
    const numbers = input.split(',').map(num => parseFloat(num.trim())).filter(num => !isNaN(num));

    if (numbers.length === 0) {
        alert('Пожалуйста, введите корректные числа');
        return;
    }

    // Часть А: Вычисление суммы до последнего отрицательного косинуса
    const sumResult = calculateSumUntilLastNegativeCosine(numbers);
    
    // Часть Б: Удаление элементов с нечётной суммой цифр целой части
    const filteredArray = filterArrayByDigitSum(numbers);

    // Отображаем результаты
    displayResults(sumResult, filteredArray);
}

function calculateSumUntilLastNegativeCosine(arr) {
    let lastNegativeCosineIndex = -1;
    
    // Находим индекс последнего элемента с отрицательным косинусом
    for (let i = 0; i < arr.length; i++) {
        if (Math.cos(arr[i]) < 0) {
            lastNegativeCosineIndex = i;
        }
    }
    
    // Если не найдено элементов с отрицательным косинусом, возвращаем сумму всего массива
    if (lastNegativeCosineIndex === -1) {
        return arr.reduce((sum, num) => sum + num, 0);
    }
    
    // Вычисляем сумму до найденного индекса включительно
    let sum = 0;
    for (let i = 0; i <= lastNegativeCosineIndex; i++) {
        sum += arr[i];
    }
    return sum;
}

function filterArrayByDigitSum(arr) {
    return arr.filter(num => {
        // Получаем целую часть числа и преобразуем её в положительное число
        const integerPart = Math.abs(Math.trunc(num));
        
        // Вычисляем сумму цифр
        const digitSum = integerPart.toString()
            .split('')
            .reduce((sum, digit) => sum + parseInt(digit), 0);
        
        // Оставляем элемент, если сумма цифр чётная
        return digitSum % 2 === 0;
    });
}

function displayResults(sum, filteredArray) {
    document.getElementById('sumResult').textContent = 
        `Результат: ${sum.toFixed(2)}`;
    
    document.getElementById('filteredResult').textContent = 
        `Результат: [${filteredArray.map(num => num.toFixed(2)).join(', ')}]`;
}