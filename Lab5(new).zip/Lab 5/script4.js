function checkPalindrome() {
    // Получаем значение из поля ввода
    const word = document.getElementById('wordInput').value.trim();
    
    // Получаем элемент для вывода результата
    const resultDiv = document.getElementById('result');
    
    // Проверяем, что поле не пустое
    if (!word) {
        showResult('Пожалуйста, введите слово', false);
        return;
    }
    
    // Очищаем слово от знаков препинания и пробелов, приводим к нижнему регистру
    const cleanWord = word.toLowerCase().replace(/[^а-яёa-z]/gi, '');
    
    // Проверяем, является ли слово палиндромом
    const isPalindrome = checkIsPalindrome(cleanWord);
    
    // Формируем текст результата
    const resultText = `
        <strong>Слово:</strong> ${word}<br>
        <strong>Результат:</strong> ${isPalindrome ? 'Это палиндром!' : 'Это не палиндром'}
    `;
    
    // Показываем результат
    showResult(resultText, isPalindrome);
}

function checkIsPalindrome(str) {
    // Сравниваем строку с её перевёрнутой версией
    return str === str.split('').reverse().join('');
}

function showResult(message, isSuccess) {
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = message;
    resultDiv.style.display = 'block';
    resultDiv.className = 'result ' + (isSuccess ? 'success' : 'error');
} 