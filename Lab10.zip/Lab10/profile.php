<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

// Получаем ID пользователя для просмотра
$view_user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : $_SESSION['user_id'];

// Проверяем права доступа
if ($view_user_id !== $_SESSION['user_id'] && !is_admin()) {
    header('Location: profile.php');
    exit;
}

// Получаем данные пользователя
$stmt = $conn->prepare("SELECT username, email, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $view_user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Получаем услуги пользователя
$stmt = $conn->prepare("
    SELECT s.* FROM services s
    JOIN user_services us ON s.id = us.service_id
    WHERE us.user_id = ?
");
$stmt->bind_param("i", $view_user_id);
$stmt->execute();
$services = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Получаем статистику
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM user_services WHERE user_id = ?");
$stmt->bind_param("i", $view_user_id);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль пользователя</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header class="header">
        <?php include 'includes/nav.php'; ?>
    </header>

    <main class="main container">
        <div class="profile-container">
            <div class="profile-header">
                <div class="profile-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
                <div class="profile-info">
                    <h2><?php echo htmlspecialchars($user['username']); ?></h2>
                    <p><?php echo htmlspecialchars($user['email']); ?></p>
                    <p>Дата регистрации: <?php echo date('d.m.Y', strtotime($user['created_at'])); ?></p>
                </div>
            </div>

            <?php if ($view_user_id === $_SESSION['user_id']): ?>
                <div class="profile-actions">
                    <a href="edit_profile.php" class="btn">
                        <i class="fas fa-edit"></i> Редактировать профиль
                    </a>
                </div>
            <?php endif; ?>

            <div class="profile-stats">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['total']; ?></div>
                    <div class="stat-label">Активных услуг</div>
                </div>
            </div>

            <div class="profile-section">
                <h3>Услуги пользователя</h3>
                <?php if (empty($services)): ?>
                    <p>Нет активных услуг</p>
                <?php else: ?>
                    <table class="services-table">
                        <thead>
                            <tr>
                                <th>Название</th>
                                <th>Описание</th>
                                <th>Цена</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($services as $service): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($service['name']); ?></td>
                                    <td><?php echo htmlspecialchars($service['description']); ?></td>
                                    <td><?php echo number_format($service['price'], 2); ?> руб.</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html> 