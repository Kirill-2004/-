<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

$result = $conn->query("SELECT * FROM services ORDER BY name");
$services = $result->fetch_all(MYSQLI_ASSOC);

// Обработка покупки услуги
if (is_logged_in() && $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buy_service'])) {
    $service_id = (int)$_POST['service_id'];
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("INSERT INTO user_services (user_id, service_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $service_id);
    
    if ($stmt->execute()) {
        $message = 'Услуга успешно приобретена';
    } else {
        $message = 'Ошибка при покупке услуги';
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Услуги</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <?php include 'includes/nav.php'; ?>
    </header>

    <main class="main container">
        <h2>Наши услуги</h2>
        <?php if (isset($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="services-grid">
            <?php foreach ($services as $service): ?>
                <div class="service-card" data-service-id="<?php echo $service['id']; ?>">
                    <h3><?php echo htmlspecialchars($service['name']); ?></h3>
                    <p><?php echo htmlspecialchars($service['description']); ?></p>
                    <p class="price">Цена: <?php echo number_format($service['price'], 2); ?> руб.</p>
                    <?php if (is_logged_in()): ?>
                        <form method="POST" action="add_to_cart.php">
                            <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                            <button type="submit" name="add_to_cart" class="btn">
                                <i class="fas fa-shopping-cart"></i> В корзину
                            </button>
                        </form>
                    <?php else: ?>
                        <p class="login-prompt">Для покупки необходимо <a href="login.php">войти</a></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <script src="assets/js/main.js"></script>
</body>
</html> 