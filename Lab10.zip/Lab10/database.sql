CREATE DATABASE sport_website CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sport_website;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE user_services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    service_id INT,
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (service_id) REFERENCES services(id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE cart (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    service_id INT,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (service_id) REFERENCES services(id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO services (name, description, price) VALUES
('Тренировки по футболу', 'Групповые тренировки по футболу с профессиональным тренером. 3 раза в неделю по 1.5 часа. Включает разминку, отработку техники, игровую практику.', 4500.00),
('Баскетбол для начинающих', 'Обучение основам баскетбола для новичков. 2 раза в неделю по 1 час. Тренировка броска, дриблинга, командной игры.', 3500.00),
('Персональные тренировки', 'Индивидуальные занятия с тренером по выбранному виду спорта. Гибкий график, персональная программа.', 2000.00),
('Волейбол', 'Тренировки по волейболу для всех уровней подготовки. 2 раза в неделю по 1.5 часа. Отработка подачи, приема, игровые комбинации.', 3000.00),
('Фитнес-зал', 'Безлимитный доступ в тренажерный зал. Современное оборудование, консультации тренера.', 2500.00),
('Йога', 'Занятия йогой для начинающих и продвинутых. 3 раза в неделю по 1 час. Развитие гибкости, силы и баланса.', 3000.00),
('Бокс', 'Тренировки по боксу с опытным тренером. 3 раза в неделю по 1 час. Техника, спарринги, физическая подготовка.', 4000.00),
('Плавание', 'Обучение плаванию для всех возрастов. 2 раза в неделю по 45 минут. Индивидуальный подход, разные стили.', 3500.00),
('Теннис', 'Занятия теннисом на крытом корте. 2 раза в неделю по 1 час. Предоставление инвентаря, обучение технике.', 4500.00),
('Детская спортивная секция', 'Общая физическая подготовка для детей 6-12 лет. 3 раза в неделю по 1 час. Развитие координации, силы, выносливости.', 3000.00); 