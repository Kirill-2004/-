<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

$message = '';
$error = '';

// Получение списка всех пользователей
$result = $conn->query("
    SELECT u.*, 
           COUNT(us.id) as services_count,
           MAX(us.purchase_date) as last_purchase
    FROM users u
    LEFT JOIN user_services us ON u.id = us.user_id
    GROUP BY u.id
    ORDER BY u.username
");
$users = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление профилями пользователей</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header class="header">
        <nav class="nav container">
            <h1>Управление профилями</h1>
            <div class="nav-links">
                <a href="index.php">Админ панель</a>
                <a href="../index.php">На сайт</a>
            </div>
        </nav>
    </header>

    <main class="main container">
        <?php if ($message): ?>
            <div class="success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="admin-profiles">
            <div class="search-box">
                <input type="text" id="searchUsers" placeholder="Поиск пользователей..." class="search-input">
            </div>

            <div class="profiles-grid">
                <?php foreach ($users as $user): ?>
                    <div class="profile-card" data-username="<?php echo htmlspecialchars($user['username']); ?>">
                        <div class="profile-card-header">
                            <div class="profile-avatar">
                                <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                            </div>
                            <div class="profile-basic-info">
                                <h3><?php echo htmlspecialchars($user['username']); ?></h3>
                                <p><?php echo htmlspecialchars($user['email']); ?></p>
                            </div>
                        </div>
                        
                        <div class="profile-details">
                            <p><i class="fas fa-calendar"></i> Регистрация: <?php echo date('d.m.Y', strtotime($user['created_at'])); ?></p>
                            <p><i class="fas fa-dumbbell"></i> Активных услуг: <?php echo $user['services_count']; ?></p>
                            <?php if ($user['last_purchase']): ?>
                                <p><i class="fas fa-clock"></i> Последняя покупка: <?php echo date('d.m.Y', strtotime($user['last_purchase'])); ?></p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="profile-actions">
                            <a href="../profile.php?user_id=<?php echo $user['id']; ?>" class="btn btn-view">
                                <i class="fas fa-eye"></i> Просмотр
                            </a>
                            <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-edit">
                                <i class="fas fa-edit"></i> Редактировать
                            </a>
                            <?php if (!$user['is_admin']): ?>
                                <form method="POST" action="delete_user.php" class="delete-form" onsubmit="return confirm('Вы уверены, что хотите удалить этого пользователя?');">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <button type="submit" class="btn btn-delete">
                                        <i class="fas fa-trash"></i> Удалить
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>

    <script>
        // Живой поиск пользователей
        document.getElementById('searchUsers').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            document.querySelectorAll('.profile-card').forEach(card => {
                const username = card.dataset.username.toLowerCase();
                card.style.display = username.includes(searchTerm) ? 'block' : 'none';
            });
        });
    </script>
</body>
</html> 