<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

$error = '';
$message = '';
$user = null;

if (isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];
    $stmt = $conn->prepare("SELECT id, username, email, is_admin FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    
    if (!$user) {
        header('Location: users.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = (int)$_POST['user_id'];
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $is_admin = isset($_POST['is_admin']) ? 1 : 0;
    $new_password = trim($_POST['new_password']);

    // Проверка уникальности имени пользователя и email
    $stmt = $conn->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
    $stmt->bind_param("ssi", $username, $email, $user_id);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        $error = 'Пользователь с таким именем или email уже существует';
    } else {
        if ($new_password) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, password = ?, is_admin = ? WHERE id = ?");
            $stmt->bind_param("sssii", $username, $email, $hashed_password, $is_admin, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, is_admin = ? WHERE id = ?");
            $stmt->bind_param("ssii", $username, $email, $is_admin, $user_id);
        }
        
        if ($stmt->execute()) {
            $message = 'Данные пользователя успешно обновлены';
            // Обновляем данные пользователя для отображения
            $user['username'] = $username;
            $user['email'] = $email;
            $user['is_admin'] = $is_admin;
        } else {
            $error = 'Ошибка при обновлении данных';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактирование пользователя</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header class="header">
        <nav class="nav container">
            <h1>Редактирование пользователя</h1>
            <div class="nav-links">
                <a href="users.php"><i class="fas fa-users"></i> К списку пользователей</a>
                <a href="../index.php"><i class="fas fa-home"></i> На сайт</a>
            </div>
        </nav>
    </header>

    <main class="main container">
        <div class="form-container">
            <?php if ($message): ?>
                <div class="success"><?php echo $message; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if ($user): ?>
                <form method="POST" action="">
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    
                    <div class="form-group">
                        <label for="username">Имя пользователя:</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">Новый пароль (оставьте пустым, чтобы не менять):</label>
                        <input type="password" id="new_password" name="new_password">
                    </div>
                    
                    <div class="form-group">
                        <label>
                            <input type="checkbox" name="is_admin" <?php echo $user['is_admin'] ? 'checked' : ''; ?>>
                            Администратор
                        </label>
                    </div>
                    
                    <button type="submit" class="btn">Сохранить изменения</button>
                </form>
            <?php endif; ?>
        </div>
    </main>
</body>
</html> 