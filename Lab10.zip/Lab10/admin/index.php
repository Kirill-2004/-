<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

// Получаем статистику
$stats = [
    'users' => $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'],
    'services' => $conn->query("SELECT COUNT(*) as count FROM services")->fetch_assoc()['count'],
    'orders' => $conn->query("SELECT COUNT(*) as count FROM user_services")->fetch_assoc()['count']
];
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ панель</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header class="header">
        <nav class="nav container">
            <h1>Админ панель</h1>
            <div class="nav-links">
                <a href="../index.php"><i class="fas fa-home"></i> На сайт</a>
                <a href="users.php"><i class="fas fa-users"></i> Пользователи</a>
                <a href="services.php"><i class="fas fa-dumbbell"></i> Услуги</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Выход</a>
            </div>
        </nav>
    </header>

    <main class="main container">
        <div class="admin-dashboard">
            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number"><?php echo $stats['users']; ?></div>
                        <div class="stat-label">Пользователей</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-dumbbell"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number"><?php echo $stats['services']; ?></div>
                        <div class="stat-label">Услуг</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-info">
                        <div class="stat-number"><?php echo $stats['orders']; ?></div>
                        <div class="stat-label">Заказов</div>
                    </div>
                </div>
            </div>

            <div class="admin-menu">
                <div class="admin-card">
                    <div class="admin-card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="admin-card-content">
                        <h3>Управление пользователями</h3>
                        <p>Просмотр и редактирование пользователей</p>
                        <div class="admin-card-actions">
                            <a href="users.php" class="btn btn-primary">
                                <i class="fas fa-arrow-right"></i> Перейти
                            </a>
                        </div>
                    </div>
                </div>
                <div class="admin-card">
                    <div class="admin-card-icon">
                        <i class="fas fa-dumbbell"></i>
                    </div>
                    <div class="admin-card-content">
                        <h3>Управление услугами</h3>
                        <p>Добавление и редактирование услуг</p>
                        <div class="admin-card-actions">
                            <a href="services.php" class="btn btn-primary">
                                <i class="fas fa-arrow-right"></i> Перейти
                            </a>
                        </div>
                    </div>
                </div>
                <div class="admin-card">
                    <div class="admin-card-icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <div class="admin-card-content">
                        <h3>Управление профилями</h3>
                        <p>Просмотр и редактирование профилей пользователей</p>
                        <div class="admin-card-actions">
                            <a href="manage_profiles.php" class="btn btn-primary">
                                <i class="fas fa-arrow-right"></i> Перейти
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html> 