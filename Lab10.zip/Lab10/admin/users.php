<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'delete' && isset($_POST['id'])) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND is_admin = 0");
        $stmt->bind_param("i", $_POST['id']);
        
        if ($stmt->execute()) {
            $message = 'Пользователь успешно удален';
        } else {
            $message = 'Ошибка при удалении пользователя';
        }
    }
    elseif ($_POST['action'] == 'toggle_admin' && isset($_POST['id'])) {
        $stmt = $conn->prepare("UPDATE users SET is_admin = NOT is_admin WHERE id = ?");
        $stmt->bind_param("i", $_POST['id']);
        
        if ($stmt->execute()) {
            $message = 'Статус администратора изменен';
        } else {
            $message = 'Ошибка при изменении статуса';
        }
    }
}

$result = $conn->query("SELECT id, username, email, is_admin, created_at FROM users ORDER BY username");
$users = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление пользователями</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="header">
        <nav class="nav container">
            <h1>Управление пользователями</h1>
            <div class="nav-links">
                <a href="index.php">Админ панель</a>
                <a href="../index.php">На сайт</a>
            </div>
        </nav>
    </header>

    <main class="main container">
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <section class="users-list">
            <h2>Список пользователей</h2>
            <table class="users-table">
                <thead>
                    <tr>
                        <th>Имя пользователя</th>
                        <th>Email</th>
                        <th>Дата регистрации</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo date('d.m.Y', strtotime($user['created_at'])); ?></td>
                            <td><?php echo $user['is_admin'] ? 'Администратор' : 'Пользователь'; ?></td>
                            <td>
                                <a href="../profile.php?user_id=<?php echo $user['id']; ?>" class="btn">
                                    <i class="fas fa-user"></i> Профиль
                                </a>
                                <form method="POST" action="" style="display: inline;">
                                    <input type="hidden" name="action" value="toggle_admin">
                                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                    <button type="submit">
                                        <?php echo $user['is_admin'] ? 'Снять админа' : 'Сделать админом'; ?>
                                    </button>
                                </form>
                                <?php if (!$user['is_admin']): ?>
                                    <form method="POST" action="delete_user.php" style="display: inline;" onsubmit="return confirm('Вы уверены, что хотите удалить этого пользователя?');">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="btn btn-delete">
                                            <i class="fas fa-trash"></i> Удалить
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html> 