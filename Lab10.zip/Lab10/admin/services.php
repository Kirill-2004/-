<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

$message = '';

// Добавление новой услуги
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'add') {
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price = floatval($_POST['price']);

        $stmt = $conn->prepare("INSERT INTO services (name, description, price) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $name, $description, $price);
        
        if ($stmt->execute()) {
            $message = 'Услуга успешно добавлена';
        } else {
            $message = 'Ошибка при добавлении услуги';
        }
    }
    // Удаление услуги
    elseif ($_POST['action'] == 'delete' && isset($_POST['id'])) {
        $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
        $stmt->bind_param("i", $_POST['id']);
        
        if ($stmt->execute()) {
            $message = 'Услуга успешно удалена';
        } else {
            $message = 'Ошибка при удалении услуги';
        }
    }
}

// Получение списка всех услуг
$result = $conn->query("SELECT * FROM services ORDER BY name");
$services = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление услугами</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="header">
        <nav class="nav container">
            <h1>Управление услугами</h1>
            <div class="nav-links">
                <a href="index.php">Админ панель</a>
                <a href="../index.php">На сайт</a>
            </div>
        </nav>
    </header>

    <main class="main container">
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <section class="add-service">
            <h2>Добавить новую услугу</h2>
            <form method="POST" action="">
                <input type="hidden" name="action" value="add">
                <div>
                    <label for="name">Название:</label>
                    <input type="text" name="name" required>
                </div>
                <div>
                    <label for="description">Описание:</label>
                    <textarea name="description" required></textarea>
                </div>
                <div>
                    <label for="price">Цена:</label>
                    <input type="number" name="price" step="0.01" required>
                </div>
                <button type="submit">Добавить услугу</button>
            </form>
        </section>

        <section class="services-list">
            <h2>Список услуг</h2>
            <div class="services-grid">
                <?php foreach ($services as $service): ?>
                    <div class="service-card">
                        <h3><?php echo htmlspecialchars($service['name']); ?></h3>
                        <p><?php echo htmlspecialchars($service['description']); ?></p>
                        <p class="price">Цена: <?php echo number_format($service['price'], 2); ?> руб.</p>
                        <form method="POST" action="" style="display: inline;">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $service['id']; ?>">
                            <button type="submit" onclick="return confirm('Вы уверены?')">Удалить</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>
</body>
</html> 