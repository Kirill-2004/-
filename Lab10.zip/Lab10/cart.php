<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Обработка удаления из корзины
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remove_from_cart'])) {
    $cart_id = (int)$_POST['cart_id'];
    $stmt = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $cart_id, $user_id);
    $stmt->execute();
}

// Обработка оформления заказа
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['checkout'])) {
    // Перенос услуг из корзины в купленные услуги
    $stmt = $conn->prepare("
        INSERT INTO user_services (user_id, service_id)
        SELECT user_id, service_id FROM cart WHERE user_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    
    if ($stmt->execute()) {
        // Очистка корзины после успешной покупки
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $success = 'Заказ успешно оформлен!';
    }
}

// Получение содержимого корзины
$stmt = $conn->prepare("
    SELECT c.id as cart_id, s.* 
    FROM cart c
    JOIN services s ON c.service_id = s.id
    WHERE c.user_id = ?
    ORDER BY c.added_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Подсчет общей стоимости
$total = array_sum(array_column($cart_items, 'price'));
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корзина</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header class="header">
        <?php include 'includes/nav.php'; ?>
    </header>

    <main class="main container">
        <div class="cart-container">
            <h2>Корзина</h2>
            
            <?php if (isset($success)): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if (empty($cart_items)): ?>
                <p class="empty-cart">Ваша корзина пуста</p>
            <?php else: ?>
                <div class="cart-items">
                    <?php foreach ($cart_items as $item): ?>
                        <div class="cart-item">
                            <div class="cart-item-info">
                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p><?php echo htmlspecialchars($item['description']); ?></p>
                                <p class="price">Цена: <?php echo number_format($item['price'], 2); ?> руб.</p>
                            </div>
                            <form method="POST" class="cart-item-remove">
                                <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                                <button type="submit" name="remove_from_cart" class="btn-remove">
                                    <i class="fas fa-trash"></i> Удалить
                                </button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="cart-summary">
                    <p class="total">Итого: <?php echo number_format($total, 2); ?> руб.</p>
                    <form method="POST">
                        <button type="submit" name="checkout" class="btn btn-checkout">Оформить заказ</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html> 