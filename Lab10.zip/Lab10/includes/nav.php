<nav class="nav container">
    <h1>Спортивный центр</h1>
    <div class="nav-links">
        <a href="<?php echo get_root_url(); ?>index.php">Главная</a>
        <a href="<?php echo get_root_url(); ?>services.php">Услуги</a>
        <?php if (is_logged_in()): ?>
            <?php if (is_admin()): ?>
                <a href="<?php echo get_root_url(); ?>admin/manage_profiles.php" class="admin-link">
                    <i class="fas fa-users-cog"></i> Управление профилями
                </a>
            <?php endif; ?>
            <a href="<?php echo get_root_url(); ?>profile.php">
                <i class="fas fa-user"></i> Профиль
            </a>
            <a href="<?php echo get_root_url(); ?>cart.php">
                <i class="fas fa-shopping-cart"></i> Корзина
                <?php
                if (is_logged_in()) {
                    $cart_count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM cart WHERE user_id = ?");
                    $user_id = $_SESSION['user_id'];
                    $cart_count_stmt->bind_param("i", $user_id);
                    $cart_count_stmt->execute();
                    $count = $cart_count_stmt->get_result()->fetch_assoc()['count'];
                    if ($count > 0) {
                        echo "<span class='cart-count'>$count</span>";
                    }
                    $cart_count_stmt->close();
                }
                ?>
            </a>
            <a href="<?php echo get_root_url(); ?>logout.php">
                <i class="fas fa-sign-out-alt"></i> Выход
            </a>
        <?php else: ?>
            <a href="<?php echo get_root_url(); ?>login.php">
                <i class="fas fa-sign-in-alt"></i> Вход
            </a>
            <a href="<?php echo get_root_url(); ?>register.php">
                <i class="fas fa-user-plus"></i> Регистрация
            </a>
        <?php endif; ?>
    </div>
</nav> 