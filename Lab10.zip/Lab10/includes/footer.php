<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Контакты</h3>
                <p><i class="fas fa-phone"></i> +7 (999) 123-45-67</p>
                <p><i class="fas fa-envelope"></i> info@sportcenter.ru</p>
                <p><i class="fas fa-map-marker-alt"></i> ул. Спортивная, 1</p>
            </div>
            
            <div class="footer-section">
                <h3>График работы</h3>
                <p>Понедельник - Пятница: 7:00 - 23:00</p>
                <p>Суббота - Воскресенье: 9:00 - 22:00</p>
            </div>
            
            <div class="footer-section">
                <h3>Социальные сети</h3>
                <div class="social-links">
                    <a href="#"><i class="fab fa-vk"></i> ВКонтакте</a>
                    <a href="#"><i class="fab fa-telegram"></i> Telegram</a>
                    <a href="#"><i class="fab fa-instagram"></i> Instagram</a>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2025 Спортивный центр. Все права защищены.</p>
        </div>
    </div>
</footer> 