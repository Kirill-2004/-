<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!is_logged_in() || !isset($_POST['service_id'])) {
    header('Location: services.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$service_id = (int)$_POST['service_id'];

// Проверяем, нет ли уже этой услуги в корзине
$stmt = $conn->prepare("SELECT id FROM cart WHERE user_id = ? AND service_id = ?");
$stmt->bind_param("ii", $user_id, $service_id);
$stmt->execute();
if ($stmt->get_result()->num_rows == 0) {
    // Добавляем в корзину
    $stmt = $conn->prepare("INSERT INTO cart (user_id, service_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $service_id);
    $stmt->execute();
}

header('Location: cart.php');
exit; 