<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Спортивный центр</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header class="header">
        <?php include 'includes/nav.php'; ?>
    </header>

    <section class="hero">
        <div class="container">
            <h1>Добро пожаловать в наш спортивный центр</h1>
            <p>Достигайте новых высот с нашими профессиональными тренерами и современным оборудованием</p>
        </div>
    </section>

    <main class="main container">
        <section class="features">
            <div class="feature-card">
                <img src="assets/images/trainer.jpg" alt="Тренеры">
                <h3>Опытные тренеры</h3>
                <p>Наши сертифицированные тренеры помогут вам достичь ваших целей</p>
            </div>
            <div class="feature-card">
                <img src="assets/images/equipment.jpg" alt="Оборудование">
                <h3>Современное оборудование</h3>
                <p>Тренажерный зал оснащен новейшим спортивным оборудованием</p>
            </div>
            <div class="feature-card">
                <img src="assets/images/program.jpg" alt="Программы">
                <h3>Разнообразные программы</h3>
                <p>Широкий выбор групповых и индивидуальных тренировок</p>
            </div>
        </section>

        <section class="about">
            <h2>О нашем центре</h2>
            <p>Наш спортивный центр - это современный комплекс, предлагающий широкий спектр услуг для поддержания здоровья и физической формы. Мы работаем с 2020 года и за это время помогли тысячам людей достичь их спортивных целей.</p>
            
            <div class="features">
                <div class="feature-card">
                    <h3>Комфортные условия</h3>
                    <p>Просторные залы, современные раздевалки, душевые кабины</p>
                </div>
                <div class="feature-card">
                    <h3>Удобное расположение</h3>
                    <p>В центре города, рядом с метро</p>
                </div>
                <div class="feature-card">
                    <h3>Гибкий график</h3>
                    <p>Работаем ежедневно с 7:00 до 23:00</p>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Контакты</h3>
                    <p><i class="fas fa-phone"></i> +7 (999) 123-45-67</p>
                    <p><i class="fas fa-envelope"></i> info@sportcenter.ru</p>
                    <p><i class="fas fa-map-marker-alt"></i> ул. Спортивная, 1</p>
                </div>
                
                <div class="footer-section">
                    <h3>График работы</h3>
                    <p>Понедельник - Пятница: 7:00 - 23:00</p>
                    <p>Суббота - Воскресенье: 9:00 - 22:00</p>
                </div>
                
                <div class="footer-section">
                    <h3>Социальные сети</h3>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-vk"></i> ВКонтакте</a>
                        <a href="#"><i class="fab fa-telegram"></i> Telegram</a>
                        <a href="#"><i class="fab fa-instagram"></i> Instagram</a>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2025 Спортивный центр. Все права защищены.</p>
            </div>
        </div>
    </footer>
</body>
</html> 