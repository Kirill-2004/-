class Calendar {
    constructor(year = new Date().getFullYear(), month = new Date().getMonth()) {
        this.date = new Date(year, month);
        this.holidays = {
            '01-01': 'Новый год',
            '02-23': 'День защитника Отечества',
            '03-08': 'Международный женский день',
            '05-01': 'Праздник Весны и Труда',
            '05-09': 'День Победы',
            '06-12': 'День России',
            '11-04': 'День народного единства'
        };
        this.initCalendar();
        this.addEventListeners();
        this.initInputs();
    }

    initInputs() {
        // Устанавливаем текущие значения в поля ввода
        document.getElementById('monthSelect').value = this.date.getMonth();
        document.getElementById('yearInput').value = this.date.getFullYear();

        // Добавляем обработчик для кнопки показа календаря
        document.getElementById('showCalendar').addEventListener('click', () => {
            const selectedMonth = parseInt(document.getElementById('monthSelect').value);
            const selectedYear = parseInt(document.getElementById('yearInput').value);

            // Проверяем корректность введенного года
            if (selectedYear >= 1900 && selectedYear <= 2100) {
                this.date = new Date(selectedYear, selectedMonth);
                this.initCalendar();
            } else {
                alert('Пожалуйста, введите год между 1900 и 2100');
            }
        });
    }

    initCalendar() {
        this.updateMonthYear();
        this.renderDays();
    }

    updateMonthYear() {
        const months = [
            'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
            'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
        ];
        document.getElementById('monthYear').textContent = 
            `${months[this.date.getMonth()]} ${this.date.getFullYear()}`;
    }

    isHoliday(date) {
        const key = date.toLocaleDateString('ru', { 
            month: '2-digit', 
            day: '2-digit' 
        });
        return this.holidays[key];
    }

    renderDays() {
        const daysContainer = document.getElementById('days');
        daysContainer.innerHTML = '';

        const firstDay = new Date(this.date.getFullYear(), this.date.getMonth(), 1);
        const lastDay = new Date(this.date.getFullYear(), this.date.getMonth() + 1, 0);
        
        // Добавляем дни предыдущего месяца
        const firstDayIndex = (firstDay.getDay() + 6) % 7;
        for (let i = firstDayIndex; i > 0; i--) {
            const day = new Date(firstDay);
            day.setDate(day.getDate() - i);
            this.createDayElement(day, true);
        }

        // Добавляем дни текущего месяца
        for (let i = 1; i <= lastDay.getDate(); i++) {
            const day = new Date(this.date.getFullYear(), this.date.getMonth(), i);
            this.createDayElement(day);
        }

        // Добавляем дни следующего месяца
        const lastDayIndex = (lastDay.getDay() + 6) % 7;
        for (let i = 1; i < 7 - lastDayIndex; i++) {
            const day = new Date(lastDay);
            day.setDate(day.getDate() + i);
            this.createDayElement(day, true);
        }
    }

    createDayElement(date, otherMonth = false) {
        const dayElement = document.createElement('div');
        dayElement.className = 'day';
        dayElement.textContent = date.getDate();

        if (otherMonth) {
            dayElement.classList.add('other-month');
        }

        // Выделяем выходные
        if (date.getDay() === 0 || date.getDay() === 6) {
            dayElement.classList.add('weekend');
        }

        // Выделяем праздники
        if (this.isHoliday(date)) {
            dayElement.classList.add('holiday');
            dayElement.title = this.isHoliday(date);
        }

        // Выделяем текущий день
        const today = new Date();
        if (date.toDateString() === today.toDateString()) {
            dayElement.classList.add('today');
        }

        document.getElementById('days').appendChild(dayElement);
    }

    addEventListeners() {
        document.getElementById('prevMonth').addEventListener('click', () => {
            this.date.setMonth(this.date.getMonth() - 1);
            this.initCalendar();
        });

        document.getElementById('nextMonth').addEventListener('click', () => {
            this.date.setMonth(this.date.getMonth() + 1);
            this.initCalendar();
        });
    }
}

// Создаем календарь при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    new Calendar();
}); 