<!DOCTYPE html>
<html>
<head>
    <title>Таблица умножения</title>
    <meta charset="utf-8">
    <style>
        table {
            border-collapse: collapse;
            margin: 20px auto;
        }
        
        td, th {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
            width: 40px;
        }
        
        th {
            background-color: #f0f0f0;
        }
        
        tr:first-child th {
            background-color: #e0e0e0;
        }
        
        th:first-child {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
    <table>
        <?php
        echo "<tr><th>&times;</th>";
        for ($i = 0; $i <= 10; $i++) {
            echo "<th>$i</th>";
        }
        echo "</tr>";
        
        for ($i = 0; $i <= 10; $i++) {
            echo "<tr>";
            echo "<th>$i</th>";
            
            for ($j = 0; $j <= 10; $j++) {
                $result = $i * $j;
                echo "<td>$result</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>