<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Календарь</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #000;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f0f0f0;
        }
        .weekend {
            background-color: #ffcccc; /* Цвет для выходных (суббота и воскресенье) */
        }
        .holiday {
            background-color: #ccffcc; /* Цвет для праздничных дней */
        }
        .form-container {
            text-align: center;
            margin-bottom: 20px;
        }
        h2 {
            text-align: center; 
        }
    </style>
</head>
<body>

<div class="form-container">
    <form method="GET" action="">
        <label for="month">Месяц (1-12):</label>
        <input type="number" id="month" name="month" min="1" max="12" required>
        <label for="year">Год:</label>
        <input type="number" id="year" name="year" min="1900" max="2100" required>
        <input type="submit" value="Показать календарь">
    </form>
</div>

<?php
function drawCalendar($month = null, $year = null) {
    // Если месяц и год не заданы, используем текущие
    if ($month === null || $year === null) {
        $month = date('n');
        $year = date('Y');  
    }

    // Определяем количество дней в месяце
    $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
    $firstDayOfMonth = mktime(0, 0, 0, $month, 1, $year);
    $dayOfWeek = date('w', $firstDayOfMonth); 

    // Праздничные дни
    $holidays = [
        '01-01', 
        '01-07',
        '02-23', 
        '03-08', 
        '05-01', 
        '05-09', 
        '06-12', 
        '12-12'  
    ];

    // Начинаем вывод таблицы
    echo "<h2>Календарь $month/$year</h2>";
    echo "<table>";
    echo "<tr><th>Пн</th><th>Вт</th><th>Ср</th><th>Чт</th><th>Пт</th><th>Сб</th><th>Вс</th></tr>";
    
   
    echo "<tr>";
    for ($i = 0; $i < $dayOfWeek; $i++) {
        echo "<td></td>";
    }

    // Заполняем дни месяца
    for ($day = 1; $day <= $daysInMonth; $day++) {
        
        $isWeekend = ($dayOfWeek == 5 || $dayOfWeek == 6); 
        
        $isHoliday = in_array(sprintf('%02d-%02d', $month, $day), $holidays);
        
        $class = '';
        if ($isWeekend) {
            $class = 'weekend';
        }
        if ($isHoliday) {
            $class = 'holiday';
        }

        // Выводим день
        echo "<td class='$class'>$day</td>";

        // Переход на следующую строку, если достигли конца недели
        $dayOfWeek++;
        if ($dayOfWeek == 7) {
            $dayOfWeek = 0;
            echo "</tr><tr>";
        }
    }

    // Закрываем последнюю строку, если она неполная
    while ($dayOfWeek < 7) {
        echo "<td></td>";
        $dayOfWeek++;
    }
    echo "</tr>";
    echo "</table>";
}

// Проверяем, были ли переданы параметры месяца и года
if (isset($_GET['month']) && isset($_GET['year'])) {
    $month = intval($_GET['month']);
    $year = intval($_GET['year']);
    drawCalendar($month, $year);
} else {
    drawCalendar(); // Если параметры не заданы, показываем текущий месяц
}
?>

</body>
</html>