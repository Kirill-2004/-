<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация пользователя</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input[type="text"], input[type="password"], input[type="date"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 4px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Регистрация пользователя</h2>
    <form method="POST" action="">
        <label for="fullname">ФИО:</label>
        <input type="text" id="fullname" name="fullname" required>

        <label for="username">Логин:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required>

        <label for="birthdate">Дата рождения:</label>
        <input type="date" id="birthdate" name="birthdate" required>

        <input type="submit" value="Зарегистрироваться">
    </form>
</div>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = htmlspecialchars(trim($_POST['fullname']));
    $username = htmlspecialchars(trim($_POST['username']));
    $password = htmlspecialchars(trim($_POST['password']));
    $birthdate = htmlspecialchars(trim($_POST['birthdate']));

    echo "<div class='form-container'>";
    echo "<h3>Регистрация успешна!</h3>";
    echo "<p><strong>ФИО:</strong> $fullname</p>";
    echo "<p><strong>Логин:</strong> $username</p>";
    echo "<p><strong>Дата рождения:</strong> $birthdate</p>";
    echo "</div>";
}
?>

</body>
</html>