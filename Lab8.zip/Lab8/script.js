function createMultiplicationTable() {
    const table = document.getElementById('multiplicationTable');
    
    // Создаем заголовок таблицы
    const headerRow = document.createElement('tr');
    headerRow.appendChild(document.createElement('td')); // Пустая ячейка в углу
    
    // Добавляем заголовки столбцов (1-10)
    for (let i = 1; i <= 10; i++) {
        const headerCell = document.createElement('td');
        headerCell.textContent = i;
        headerRow.appendChild(headerCell);
    }
    table.appendChild(headerRow);
    
    // Создаем строки таблицы
    for (let i = 1; i <= 10; i++) {
        const row = document.createElement('tr');
        
        // Добавляем заголовок строки
        const rowHeader = document.createElement('td');
        rowHeader.textContent = i;
        row.appendChild(rowHeader);
        
        // Добавляем результаты умножения
        for (let j = 1; j <= 10; j++) {
            const cell = document.createElement('td');
            cell.textContent = i * j;
            row.appendChild(cell);
        }
        
        table.appendChild(row);
    }
}

// Создаем таблицу при загрузке страницы
document.addEventListener('DOMContentLoaded', createMultiplicationTable); 