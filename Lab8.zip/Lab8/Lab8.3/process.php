<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Функция для очистки входных данных
function cleanInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Массив для хранения ошибок
$errors = [];

// Проверяем, была ли отправлена форма
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Получаем и очищаем данные из формы
    $lastname = cleanInput($_POST["lastname"] ?? '');
    $firstname = cleanInput($_POST["firstname"] ?? '');
    $middlename = cleanInput($_POST["middlename"] ?? '');
    $login = cleanInput($_POST["login"] ?? '');
    $password = cleanInput($_POST["password"] ?? '');
    $confirm_password = cleanInput($_POST["confirm_password"] ?? '');
    $birthdate = cleanInput($_POST["birthdate"] ?? '');

    // Валидация фамилии
    if (empty($lastname)) {
        $errors[] = "Фамилия обязательна для заполнения";
    }

    // Валидация имени
    if (empty($firstname)) {
        $errors[] = "Имя обязательно для заполнения";
    }

    // Валидация логина
    if (empty($login)) {
        $errors[] = "Логин обязателен для заполнения";
    }

    // Валидация пароля
    if (empty($password)) {
        $errors[] = "Пароль обязателен для заполнения";
    }

    // Проверка совпадения паролей
    if ($password !== $confirm_password) {
        $errors[] = "Пароли не совпадают";
    }

    // Валидация даты рождения
    if (empty($birthdate)) {
        $errors[] = "Дата рождения обязательна для заполнения";
    }

    // Если нет ошибок, выводим успешное сообщение
    if (empty($errors)) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Успешная регистрация</title>
            <meta charset="UTF-8">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    margin: 0;
                    padding: 20px;
                    background-color: #f0f2f5;
                }
                .success-container {
                    max-width: 600px;
                    margin: 40px auto;
                    padding: 20px;
                    background-color: white;
                    border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }
                .success-header {
                    color: #28a745;
                    text-align: center;
                    margin-bottom: 20px;
                }
                .user-data {
                    background-color: #f8f9fa;
                    padding: 15px;
                    border-radius: 4px;
                    margin-bottom: 20px;
                }
                .back-button {
                    display: inline-block;
                    padding: 10px 20px;
                    background-color: #007bff;
                    color: white;
                    text-decoration: none;
                    border-radius: 4px;
                }
            </style>
        </head>
        <body>
            <div class="success-container">
                <h2 class="success-header">Регистрация успешно завершена!</h2>
                
                <div class="user-data">
                    <h3>Ваши данные:</h3>
                    <p><strong>ФИО:</strong> <?php echo $lastname . ' ' . $firstname . ' ' . $middlename; ?></p>
                    <p><strong>Логин:</strong> <?php echo $login; ?></p>
                    <p><strong>Дата рождения:</strong> <?php echo $birthdate; ?></p>
                </div>

                <div style="text-align: center;">
                    <a href="register.html" class="back-button">Вернуться к форме регистрации</a>
                </div>
            </div>
        </body>
        </html>
        <?php
    } else {
        // Если есть ошибки, выводим их
        echo "<h2>Ошибки при регистрации:</h2><ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
        echo "<a href='register.html'>Вернуться к форме регистрации</a>";
    }
} else {
    // Если форма не была отправлена, перенаправляем на страницу регистрации
    header("Location: register.html");
    exit();
}
?>