class Calculator {
    constructor() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
        this.updateDisplay();
    }

    clear() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
    }

    clearEntry() {
        this.currentOperand = '0';
    }

    delete() {
        if (this.currentOperand === '0') return;
        this.currentOperand = this.currentOperand.slice(0, -1);
        if (this.currentOperand === '') this.currentOperand = '0';
    }

    appendNumber(number) {
        if (number === '.' && this.currentOperand.includes('.')) return;
        if (this.currentOperand === '0' && number !== '.') {
            this.currentOperand = number;
        } else {
            this.currentOperand += number;
        }
    }

    chooseOperation(operation) {
        if (this.currentOperand === '') return;
        if (this.previousOperand !== '') {
            this.compute();
        }
        this.operation = operation;
        this.previousOperand = this.currentOperand;
        this.currentOperand = '';
    }

    compute() {
        let computation;
        const prev = parseFloat(this.previousOperand);
        const current = parseFloat(this.currentOperand);
        if (isNaN(prev) || isNaN(current)) return;

        switch (this.operation) {
            case '+':
                computation = prev + current;
                break;
            case '-':
                computation = prev - current;
                break;
            case '×':
                computation = prev * current;
                break;
            case '÷':
                if (current === 0) {
                    alert('Деление на ноль невозможно');
                    return;
                }
                computation = prev / current;
                break;
            default:
                return;
        }

        this.currentOperand = computation.toString();
        this.operation = undefined;
        this.previousOperand = '';
    }

    specialOperation(operation) {
        let number = parseFloat(this.currentOperand);
        switch (operation) {
            case 'sqrt':
                if (number < 0) {
                    alert('Невозможно извлечь корень из отрицательного числа');
                    return;
                }
                this.currentOperand = Math.sqrt(number).toString();
                break;
            case 'square':
                this.currentOperand = (number * number).toString();
                break;
            case 'inverse':
                if (number === 0) {
                    alert('Деление на ноль невозможно');
                    return;
                }
                this.currentOperand = (1 / number).toString();
                break;
            case 'negate':
                this.currentOperand = (-number).toString();
                break;
            case 'percent':
                this.currentOperand = (number / 100).toString();
                break;
        }
    }

    updateDisplay() {
        document.querySelector('.current-operand').textContent = this.currentOperand;
        if (this.operation != null) {
            document.querySelector('.previous-operand').textContent = 
                `${this.previousOperand} ${this.operation}`;
        } else {
            document.querySelector('.previous-operand').textContent = '';
        }
    }
}

const calculator = new Calculator();

// Обработчики событий для цифр
document.querySelectorAll('.number').forEach(button => {
    button.addEventListener('click', () => {
        calculator.appendNumber(button.textContent);
        calculator.updateDisplay();
    });
});

// Обработчики событий для операций
document.querySelectorAll('.operation').forEach(button => {
    button.addEventListener('click', () => {
        const action = button.dataset.action;
        switch (action) {
            case 'add':
            case 'subtract':
            case 'multiply':
            case 'divide':
                calculator.chooseOperation(button.textContent);
                break;
            case 'c':
                calculator.clear();
                break;
            case 'ce':
                calculator.clearEntry();
                break;
            case 'backspace':
                calculator.delete();
                break;
            case 'sqrt':
            case 'square':
            case 'inverse':
            case 'negate':
            case 'percent':
                calculator.specialOperation(action);
                break;
        }
        calculator.updateDisplay();
    });
});

// Обработчик для равно
document.querySelector('.equals').addEventListener('click', () => {
    calculator.compute();
    calculator.updateDisplay();
});

// Обработка клавиатуры
document.addEventListener('keydown', event => {
    if (/[0-9]/.test(event.key)) {
        calculator.appendNumber(event.key);
    } else if (event.key === '.') {
        calculator.appendNumber('.');
    } else if (event.key === 'Enter') {
        calculator.compute();
    } else if (event.key === 'Backspace') {
        calculator.delete();
    } else if (event.key === 'Escape') {
        calculator.clear();
    } else if (['+', '-', '*', '/'].includes(event.key)) {
        const operations = {
            '+': '+',
            '-': '-',
            '*': '×',
            '/': '÷'
        };
        calculator.chooseOperation(operations[event.key]);
    }
    calculator.updateDisplay();
}); 