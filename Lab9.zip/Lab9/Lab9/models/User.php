<?php
class User {
    private $conn;
    private $table_name = "users";
    public $user_id;
    public $username;
    public $email;
    public $password;
    public $first_name;
    public $last_name;
    public $role_id;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Регистрация нового пользователя
    public function register() {
        // Проверяем существование email
        if($this->emailExists($this->email)) {
            return array(
                "success" => false,
                "message" => "Этот email уже зарегистрирован"
            );
        }

        $query = "INSERT INTO " . $this->table_name . "
                SET
                    username = :username,
                    email = :email,
                    password_hash = :password,
                    first_name = :first_name,
                    last_name = :last_name,
                    role_id = 2"; // 2 - роль обычного пользователя

        $stmt = $this->conn->prepare($query);

        $this->password = password_hash($this->password, PASSWORD_DEFAULT);

        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":password", $this->password);
        $stmt->bindParam(":first_name", $this->first_name);
        $stmt->bindParam(":last_name", $this->last_name);

        try {
            $stmt->execute();
            return array(
                "success" => true,
                "message" => "Регистрация успешна"
            );
        } catch(PDOException $e) {
            return array(
                "success" => false,
                "message" => "Ошибка регистрации: " . $e->getMessage()
            );
        }
    }

    // Авторизация пользователя
    public function login($username, $password) {
        $query = "SELECT user_id, username, password_hash, role_id
                FROM " . $this->table_name . "
                WHERE username = ?";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $username);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if($row && password_verify($password, $row['password_hash'])) {
            return $row;
        }
        return false;
    }

    // Получение данных пользователя по ID
    public function getUserById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE user_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Обновление данных пользователя
    public function update() {
        // Проверяем права доступа
        if (!isAdmin() && !checkUserAccess($this->user_id)) {
            return false;
        }

        $query = "UPDATE " . $this->table_name . "
                SET
                    email = :email,
                    first_name = :first_name,
                    last_name = :last_name
                WHERE user_id = :user_id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":first_name", $this->first_name);
        $stmt->bindParam(":last_name", $this->last_name);
        $stmt->bindParam(":user_id", $this->user_id);

        return $stmt->execute();
    }

    // Удаление пользователя (только для администраторов)
    public function delete($user_id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE user_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $user_id);
        return $stmt->execute();
    }

    // Получение списка всех пользователей (для администраторов)
    public function getAllUsers() {
        $query = "SELECT u.*, r.role_name 
                FROM " . $this->table_name . " u 
                JOIN roles r ON u.role_id = r.role_id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Проверка существования email
    public function emailExists($email) {
        $query = "SELECT user_id FROM " . $this->table_name . " WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $email);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }
}
?> 