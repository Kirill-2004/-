<?php
require_once '../auth/check_auth.php';
require_once '../config/database.php';
require_once '../models/User.php';

// Проверяем права администратора
if (!isAdmin()) {
    header("Location: ../login.php");
    exit;
}

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

$message = '';
$messageType = '';

// Обработка удаления пользователя
if (isset($_POST['delete_user'])) {
    if ($user->delete($_POST['user_id'])) {
        $message = "Пользователь успешно удален";
        $messageType = "success";
    } else {
        $message = "Ошибка при удалении пользователя";
        $messageType = "error";
    }
}

// Получаем список всех пользователей
$users = $user->getAllUsers();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Управление пользователями</title>
    <style>
        .error { color: red; }
        .success { color: green; }
        table { 
            border-collapse: collapse; 
            width: 100%;
        }
        th, td { 
            border: 1px solid #ddd; 
            padding: 8px; 
            text-align: left;
        }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Управление пользователями</h2>
    
    <?php if($message): ?>
        <div class="<?php echo $messageType; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>Имя пользователя</th>
            <th>Email</th>
            <th>Роль</th>
            <th>Действия</th>
        </tr>
        <?php foreach($users as $user_item): ?>
        <tr>
            <td><?php echo htmlspecialchars($user_item['user_id']); ?></td>
            <td><?php echo htmlspecialchars($user_item['username']); ?></td>
            <td><?php echo htmlspecialchars($user_item['email']); ?></td>
            <td><?php echo htmlspecialchars($user_item['role_name']); ?></td>
            <td>
                <a href="edit_user.php?id=<?php echo $user_item['user_id']; ?>">Редактировать</a>
                <form method="POST" style="display: inline;" onsubmit="return confirm('Вы уверены?');">
                    <input type="hidden" name="user_id" value="<?php echo $user_item['user_id']; ?>">
                    <button type="submit" name="delete_user">Удалить</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <p><a href="../profile.php">Вернуться в профиль</a></p>
</body>
</html> 